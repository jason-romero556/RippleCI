package com.example.mymapfeature

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.mymapfeature.ui.theme.MyMapFeatureTheme
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyMapFeatureTheme {
                MyMapApp()
            }
        }
    }
}

@Composable
fun MyMapApp() {
    var expanded by remember { mutableStateOf(false) }
    var selectedBuilding by remember { mutableStateOf("Select a building") }
    var selectedLocation by remember { mutableStateOf<LatLng?>(null) }

    val buildings = mapOf(
        "Sierra Hall" to LatLng(34.162310, -119.044454),
        "Library" to LatLng(34.162674, -119.040705),
        "Bell Tower" to LatLng(34.1615, -119.0429),
        "El Dorado hall" to LatLng(34.162674, -119.040705),
        "Aliso Hall" to LatLng(34.162674, -119.040705),
        "Placer Hall" to LatLng(34.162674, -119.040705),
        "Solano Hall" to LatLng(34.162674, -119.040705),
        "Gateway Hall" to LatLng(34.162674, -119.040705),
        "Shasta Hall" to LatLng(34.162674, -119.040705),
        "Marin Hall" to LatLng(34.162674, -119.040705),
        "Arroyo hall" to LatLng(34.162674, -119.040705),
        "Library" to LatLng(34.162674, -119.040705),
        "Island Kitchen" to LatLng(34.162674, -119.040705),
        "Ekho's Cafe" to LatLng(34.162674, -119.040705),
        "Santa Rosa Housing" to LatLng(34.162674, -119.040705),
        "Anacapa Housing" to LatLng(34.162674, -119.040705),
        "Town center" to LatLng(34.162674, -119.040705),
        "Santa Cruz Housing" to LatLng(34.162674, -119.040705),
        "CSUCI Cove Bookstore" to LatLng(34.162674, -119.040705)
    )

    val cameraPositionState = rememberCameraPositionState()

    LaunchedEffect(selectedLocation) {
        selectedLocation?.let {
            cameraPositionState.move(
                CameraUpdateFactory.newLatLngZoom(it, 17f)
            )
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Button(onClick = { expanded = true }) {
            Text(selectedBuilding)
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            buildings.forEach { (name, location) ->
                DropdownMenuItem(
                    text = { Text(name) },
                    onClick = {
                        selectedBuilding = name
                        selectedLocation = location
                        expanded = false
                    }
                )
            }
        }

        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState
        ) {
            selectedLocation?.let {
                Marker(
                    state = MarkerState(position = it),
                    title = selectedBuilding
                )
            }
        }
    }
}